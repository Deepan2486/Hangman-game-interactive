README FILE:

Name: Deepan Maitra
Entry no.: 2019CSB1044

**HOW TO PLAY THE GAME?**

1. At start, the unguessed word will be shown with blank spaces representing unguessed letters. 
2. User will be asked to enter a letter. 
3. If the letter occurs in the word, it will take its correct guesses. Otherwise it will show "wrong guess" and proceed to next turn. 
4. After each turn, the current hangman will be displayed, along with number of tries left. 
5. After each turn, a list of already entered characters will also be shown. 
6. If user again enters a letter already entered previously, no turn will be lost. 
7. The game ends when: user types the entire correct word (win) OR user guesses all the letters one by one (win) OR user runs out of 6 allowed incorrect attempts (lost/ hangman diagram complete)


**Additional details in program:**

1. The program has been modularized using several subroutines, which are declared at the start of the code. 
2. The word selection is random from the list of words defined in the code. 
3. Upper case letters and small case letters make no difference as user input. 
4. The hangman will be complete in 6 incorrect guesses. 

Thank you. 